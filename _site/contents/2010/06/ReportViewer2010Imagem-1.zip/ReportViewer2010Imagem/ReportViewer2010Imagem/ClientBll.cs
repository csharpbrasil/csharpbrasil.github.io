﻿using System.Collections.Generic;
using System.Drawing;
using System.IO;

namespace ReportViewer2010Imagem
{
    public class ClientBll
    {
        public List<ClientInfo> GetAll()
        {
            List<ClientInfo> lst = new List<ClientInfo>();

            ClientInfo clientInfoA = new ClientInfo();
            clientInfoA.Id = 1;
            clientInfoA.Name = "Alessandra";
            clientInfoA.Photo = ImageToByteArray(Image.FromFile(Directory.GetCurrentDirectory() + @"\rostoA.jpg"));

            ClientInfo clientInfoB = new ClientInfo();
            clientInfoB.Id = 2;
            clientInfoB.Name = "Renata";
            clientInfoB.Photo = ImageToByteArray(Image.FromFile(Directory.GetCurrentDirectory() + @"\rostoB.png"));

            lst.Add(clientInfoA);
            lst.Add(clientInfoB);

            return lst;
        }

        public byte[] ImageToByteArray(System.Drawing.Image imageIn)
        {
            MemoryStream ms = new MemoryStream();
            imageIn.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
            return ms.ToArray();
        }
    }
}
