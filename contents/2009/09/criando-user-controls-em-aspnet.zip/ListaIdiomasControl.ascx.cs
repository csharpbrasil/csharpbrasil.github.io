﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ListaIdiomasControl : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnIncluir_Click(object sender, EventArgs e)
    {
        // Recuperar informação do TextBox
        string Idioma = txtIdioma.Text.Trim();
        // Cria um novo item do idioma
        ListItem item = new ListItem(Idioma);
        // Atribui o item a nossa lista
        lstIdiomas.Items.Add(item);
        // Limpa o TextBox
        txtIdioma.Text = string.Empty;
    }

    protected void btnExcluir_Click(object sender, EventArgs e)
    {
        // Recupera o item
        ListItem item = lstIdiomas.Items.FindByValue(lstIdiomas.SelectedValue);
        // Remove da lista
        lstIdiomas.Items.Remove(item);
    }
}
