﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }

    public DataTable CarregaDados()
    {
        string ConnectionString = @"Data Source=.\SQLEXPRESS;User Id=sa;Password=123456;Initial Catalog=estudos;";

        DataTable dt = new DataTable();

        using (SqlConnection connection = new SqlConnection(ConnectionString))
        {
            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = connection;
                command.CommandText = "select * from contatos";

                using (SqlDataAdapter adapter = new SqlDataAdapter())
                {
                    adapter.SelectCommand = command;
                    adapter.Fill(dt);
                }
            }
        }

        return dt;
    }

    protected void btnCarregarDados_Click(object sender, EventArgs e)
    {
        DataTable dt = CarregaDados();
        gridContatos.DataSource = dt;
        gridContatos.DataBind();

        Session.Add("Contatos2Excel", dt);
    }

    protected void btnExportarExcel_Click(object sender, EventArgs e)
    {
        Response.Redirect("exporta_excel.aspx");
    }
}
