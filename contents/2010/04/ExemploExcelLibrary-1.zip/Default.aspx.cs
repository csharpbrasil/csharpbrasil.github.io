﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnProcessarExcel_Click(object sender, EventArgs e)
    {
        if (fupArquivo.HasFile)
        {
            // Recebe o arquivo em array de bytes
            byte[] buffer = fupArquivo.FileBytes;
            // Criar o arquivo em memoria
            System.IO.MemoryStream stream = new System.IO.MemoryStream(buffer);
            // Carrega o WorkBook do Excel
            ExcelLibrary.SpreadSheet.Workbook workbook = ExcelLibrary.SpreadSheet.Workbook.Load(stream);
            // Recupera o primeiro WorkSheet
            ExcelLibrary.SpreadSheet.Worksheet worksheet = workbook.Worksheets[0];

            // Cria uma tabela para armazenar o Excel
            System.Data.DataTable dtExcel = new System.Data.DataTable();
            dtExcel.Columns.Add("Coluna0", typeof(string));
            dtExcel.Columns.Add("Coluna1", typeof(string));
            
            // Percorre as linhas do Excel
            for (int rowIndex = worksheet.Cells.FirstRowIndex; rowIndex <= worksheet.Cells.LastRowIndex; rowIndex++)
            {
                // Recupera a linha do Excel
                ExcelLibrary.SpreadSheet.Row row = worksheet.Cells.GetRow(rowIndex);

                // Adiciona os dados na tabela
                System.Data.DataRow newRow = dtExcel.NewRow();
                newRow["Coluna0"] = row.GetCell(0).StringValue;
                newRow["Coluna1"] = row.GetCell(1).StringValue;
                dtExcel.Rows.Add(newRow);
            }

            // Adicona a tabela com os dados do Excel no Grid
            gridExcelProcessado.DataSource = dtExcel;
            gridExcelProcessado.DataBind();
        }
    }

    protected void btnCriarExcel_Click(object sender, EventArgs e)
    {
        string file = "C:\\excel_exemplo.xls";
        ExcelLibrary.SpreadSheet.Workbook workbook = new ExcelLibrary.SpreadSheet.Workbook();
        ExcelLibrary.SpreadSheet.Worksheet worksheet = new ExcelLibrary.SpreadSheet.Worksheet("Planilha1");
        worksheet.Cells[0, 0] = new ExcelLibrary.SpreadSheet.Cell("Cliente1");
        worksheet.Cells[0, 1] = new ExcelLibrary.SpreadSheet.Cell("2344,89");

        worksheet.Cells[1, 0] = new ExcelLibrary.SpreadSheet.Cell("Cliente2");
        worksheet.Cells[1, 1] = new ExcelLibrary.SpreadSheet.Cell("1342,00");

        worksheet.Cells[2, 0] = new ExcelLibrary.SpreadSheet.Cell("Cliente3");
        worksheet.Cells[2, 1] = new ExcelLibrary.SpreadSheet.Cell("7634,78");

        worksheet.Cells[3, 0] = new ExcelLibrary.SpreadSheet.Cell("Cliente4");
        worksheet.Cells[3, 1] = new ExcelLibrary.SpreadSheet.Cell("4322,44");

        workbook.Worksheets.Add(worksheet);
        workbook.Save(file);
    }
}
